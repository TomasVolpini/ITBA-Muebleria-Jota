import React from "react";

const RedesCard = () => {
  return (
    <div className="card redes-card">
      <h3>Contacto Digital</h3>
      <p>generalinfo@hermanosjota.com.ar</p>
      <p>ventas@hermanosjota.com.ar</p>
      <p>@hermanosjota_ba</p>
      <p>+54 11 4567-8900</p>
    </div>
  );
};

export default RedesCard;
