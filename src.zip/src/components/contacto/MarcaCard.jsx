import React from "react";

const MarcaCard = () => {
  return (
    <div className="card marca-card">
      <h3>HJ</h3>
      <p>ARTESANÍA</p>
    </div>
  );
};

export default MarcaCard;
