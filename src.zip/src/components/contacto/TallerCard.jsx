import React from "react";

const TallerCard = () => {
  return (
    <div className="card taller-card">
      <h3>Nuestro Taller</h3>
    </div>
  );
};

export default TallerCard;
