import React from "react";
import ContactoPage from "./components/contacto/ContactoPage";

function App() {
  return (
    <div>
      <ContactoPage />
    </div>
  );
}

export default App;
